ART CLASSES 2027 ANDROID APP PROJECT

This is an Android Studio project wrapping the supplied mobile HTML page in a WebView.

Build APK:
1. Install Android Studio on your computer.
2. Open this folder (ArtClassesAndroid) as a project.
3. Allow Gradle sync to finish.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The APK will be in app/build/outputs/apk/debug/.

No internet permission is required for the bundled page itself. Links to WhatsApp/external
websites are handed off to Android apps/browser.
